package com.manasesapplication.app

import com.manasesapplication.app.appcomponents.base.BaseActivity
import com.manasesapplication.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}